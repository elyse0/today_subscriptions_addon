
setTimeout(function () {

    // Subscriptions
    borrar = document.querySelector("div.ytd-section-list-renderer:nth-child(3)")
    borrar.remove()

    library = document.querySelector("div.ytd-guide-collapsible-section-entry-renderer:nth-child(1)")
    library.remove()

    bar = document.querySelector("ytd-guide-collapsible-section-entry-renderer.style-scope")
    bar.remove()

    youtube = document.querySelector("ytd-section-list-renderer.style-scope > div:nth-child(2)").childNodes

    for (var i=0;i < youtube.length; i++){
        if(i!==0)
            youtube[i].style.display='none'
    }
}, 5000);

// Leftbar






console.log("Amish")